package common;

public class URIConfig {
	public static final String BASE_URL = "http://localhost:8081/waesheroes/api/v1/users";
	public static final String ACCESS = "/access";
	public static final String ALL = "/all";
	public static final String DETAILS = "/details";
	
}
